package com.example.DemoGit;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoGitApplicationTests {

	@Test
	void contextLoads() {
	}

}
